create view V_CONSULTAS_PACIENTES as
SELECT 
    p.nm_paciente AS nome_paciente,
    c.dt_hr_consulta AS data_consulta,
    c.vl_consulta AS valor_consulta,
    f.nm_forma_pagto AS forma_pagamento
FROM 
    t_rhstu_paciente p
JOIN 
    t_rhstu_consulta c ON p.id_paciente = c.id_paciente
JOIN 
    t_rhstu_consulta_forma_pagto cp ON c.nr_consulta = cp.nr_consulta AND c.id_unid_hospital = cp.id_unid_hospital
JOIN 
    t_rhstu_forma_pagamento f ON cp.id_forma_pagto = f.id_forma_pagto
/

