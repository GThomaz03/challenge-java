create view V_TOPN_MEDIC_RM88888_RM99999 as
SELECT 
    m.id_medicamento AS codigo_medicamento,  -- Adicionando o código do medicamento
    m.nm_medicamento AS nome_medicamento,
    COUNT(p.id_medicamento) AS quantidade_receitas
FROM 
    T_RHSTU_PRESCICAO_MEDICA p
JOIN 
    T_RHSTU_MEDICAMENTO m ON p.id_medicamento = m.id_medicamento
GROUP BY 
    m.id_medicamento,  -- Incluindo o código do medicamento na cláusula GROUP BY
    m.nm_medicamento
ORDER BY 
    quantidade_receitas DESC
/

