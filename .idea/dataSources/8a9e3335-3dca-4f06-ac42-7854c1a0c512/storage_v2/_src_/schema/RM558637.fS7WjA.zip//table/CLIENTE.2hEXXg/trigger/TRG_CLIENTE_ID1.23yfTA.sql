create trigger TRG_CLIENTE_ID1
    before insert
    on CLIENTE
    for each row
BEGIN
    :NEW.id := cliente_seq.NEXTVAL;
END;
/

