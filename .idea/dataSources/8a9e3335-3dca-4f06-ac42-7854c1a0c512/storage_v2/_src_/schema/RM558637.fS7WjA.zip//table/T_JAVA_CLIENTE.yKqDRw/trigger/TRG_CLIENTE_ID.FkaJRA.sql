create trigger TRG_CLIENTE_ID
    before insert
    on T_JAVA_CLIENTE
    for each row
BEGIN
    :new.ID_CLIENTE := cliente_seq.NEXTVAL;
END;
/

