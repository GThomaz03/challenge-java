create view V_CONSULTA_DIASEMANA_RM88888 as
SELECT
    TO_CHAR(dt_hr_consulta, 'DY', 'NLS_DATE_LANGUAGE=PORTUGUESE') AS dia_semana,
    TO_CHAR(dt_hr_consulta, 'HH24') AS hora,
    COUNT(*) AS total_consultas
FROM
    t_rhstu_consulta
GROUP BY
    TO_CHAR(dt_hr_consulta, 'DY', 'NLS_DATE_LANGUAGE=PORTUGUESE'),
    TO_CHAR(dt_hr_consulta, 'HH24')
ORDER BY
    dia_semana,
    hora
/

